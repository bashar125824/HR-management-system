## Hacker Rank

Thursdays code challenges aims to add some points to your hacker rank account

please create your own account and try to solve as much as you can even if it was not an assignment, since
a lot of employers take hacker rank profile into consideration

### .nnb file

Basically it is a notebook where you can write MD and JS in the same time.

And Mainly to run codes that require so much time separately.

You need to install the following extensions:

- [Node.js Notebooks (REPL)](https://marketplace.visualstudio.com/items?itemName=donjayamanne.typescript-notebook)
- [Jupyter](https://marketplace.visualstudio.com/items?itemName=ms-toolsai.jupyter)
