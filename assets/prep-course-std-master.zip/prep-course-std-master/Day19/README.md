# Day 19

## Outcomes
Students will learn :

- Able to create new object from Modal data and store it Database
- Retrieve data from DB and show them.
- Able to delete/update from DB (choose one of them to explain and leave the other for the task).
- Deployment on netlify

## Resources
* [React Bootstrap](https://react-bootstrap.github.io/getting-started/introduction/)
* [Netlify Deployment Guide](https://www.netlify.com/blog/2016/09/29/a-step-by-step-guide-deploying-on-netlify/)


### Keywords to search for (Main Headlines):
* React bootstrap.