# Day05

## Outcomes:
Students will be able to:
- Know the difference between the Interpreted and Compiled Programming Languages.
- Use the JavaScript Popup Boxes (Alert box, Confirm box, and Prompt box).
- Declare variables and knowing the difference between data types.
- Learn about the Comparison operators and Logical operators.
- Use Conditional Statements.


## Resources:

- [JavaScript MDN](https://developer.mozilla.org/en-US/docs/Web/JavaScript?retiredLocale=ar)
- [The Modern JavaScript Tutorial](https://javascript.info/)
- [JavaScript w3schools](https://www.w3schools.com/js/default.asp)

