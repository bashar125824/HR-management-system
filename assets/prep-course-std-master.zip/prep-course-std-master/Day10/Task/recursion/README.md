# Task 10

In today's Task you are going to solve the required problems inside your javascript file.

Your code should pass all test.

To run all the tests `npm test`